import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, MessageCircle } from 'lucide-react';
import { CartItem, Order, OrderStatus } from '../types';
import { CURRENCY_SYMBOL } from '../constants';

interface CartSheetProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  updateQuantity: (id: number, delta: number) => void;
  removeFromCart: (id: number) => void;
  clearCart: () => void;
  whatsappNumber: string;
}

const CartSheet: React.FC<CartSheetProps> = ({ 
  isOpen, 
  onClose, 
  cartItems, 
  updateQuantity, 
  removeFromCart,
  clearCart,
  whatsappNumber
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = () => {
    if (!name || !phone || !address) {
      alert("Please fill in all details");
      return;
    }

    setIsSubmitting(true);

    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      customerName: name,
      customerPhone: phone,
      address: address,
      items: [...cartItems],
      total: total,
      status: OrderStatus.PENDING,
      timestamp: Date.now()
    };

    // Save to local storage for Admin simulation
    const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    localStorage.setItem('orders', JSON.stringify([newOrder, ...existingOrders]));
    
    // Save last order ID for user tracking
    localStorage.setItem('lastOrderId', newOrder.id);

    // Construct WhatsApp Message
    let message = `*New Order: ${newOrder.id}*\n\n`;
    message += `*Customer:* ${name}\n`;
    message += `*Phone:* ${phone}\n`;
    message += `*Address:* ${address}\n\n`;
    message += `*Order Details:*\n`;
    cartItems.forEach(item => {
      message += `- ${item.quantity}x ${item.name} (${CURRENCY_SYMBOL}${item.price})\n`;
    });
    message += `\n*Total Amount:* ${CURRENCY_SYMBOL}${total}\n`;
    message += `\nPlease confirm my order!`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;

    // Clear cart and redirect
    setTimeout(() => {
      clearCart();
      setIsSubmitting(false);
      onClose();
      window.open(whatsappUrl, '_blank');
      alert(`Order placed! Your Order ID is ${newOrder.id}. Go to 'Track Order' to see status.`);
    }, 1000);
  };

  return (
    <div className={`fixed inset-0 z-50 overflow-hidden ${isOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}>
      <div 
        className={`absolute inset-0 bg-black bg-opacity-50 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`} 
        onClick={onClose}
      />
      
      <div className={`absolute inset-y-0 right-0 max-w-md w-full bg-white shadow-xl transform transition-transform duration-300 flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
          <h2 className="text-lg font-bold text-gray-900">Your Cart</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {cartItems.length === 0 ? (
            <div className="text-center text-gray-500 mt-10">
              <p className="text-xl mb-2">Your cart is empty</p>
              <p className="text-sm">Add some delicious food!</p>
            </div>
          ) : (
            cartItems.map(item => (
              <div key={item.id} className="flex gap-4 items-start">
                <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800">{item.name}</h3>
                  <p className="text-primary font-bold text-sm">{CURRENCY_SYMBOL}{item.price}</p>
                  
                  <div className="flex items-center gap-3 mt-2">
                    <button 
                      onClick={() => updateQuantity(item.id, -1)}
                      className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="font-medium text-sm w-4 text-center">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.id, 1)}
                      className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600"
                    >
                      <Plus size={14} />
                    </button>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="ml-auto text-red-500 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer / Checkout Form */}
        {cartItems.length > 0 && (
          <div className="border-t border-gray-200 p-6 bg-gray-50">
            <div className="flex justify-between items-center mb-6">
              <span className="font-semibold text-gray-600">Total</span>
              <span className="text-2xl font-bold text-gray-900">{CURRENCY_SYMBOL}{total}</span>
            </div>

            <div className="space-y-3 mb-6">
                <input 
                  type="text" 
                  placeholder="Your Name" 
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
                <input 
                  type="tel" 
                  placeholder="Phone Number" 
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
                <textarea 
                  placeholder="Delivery Address" 
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none h-20 resize-none"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
            </div>

            <button 
              onClick={handleCheckout}
              disabled={isSubmitting}
              className="w-full bg-[#25D366] hover:bg-[#20b85a] text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg disabled:opacity-50"
            >
              <MessageCircle size={20} />
              {isSubmitting ? 'Processing...' : 'Order via WhatsApp'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartSheet;