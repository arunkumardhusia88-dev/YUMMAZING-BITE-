import React from 'react';
import { ShoppingBag, Search, Menu, ChefHat, Truck, User } from 'lucide-react';
import { ViewState, AppSettings } from '../types';

interface NavbarProps {
  cartCount: number;
  setIsCartOpen: (isOpen: boolean) => void;
  setViewState: (view: ViewState) => void;
  currentView: ViewState;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  settings: AppSettings;
}

const Navbar: React.FC<NavbarProps> = ({ 
  cartCount, 
  setIsCartOpen, 
  setViewState, 
  currentView, 
  searchQuery, 
  setSearchQuery,
  settings 
}) => {
  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 gap-4">
          
          {/* Logo */}
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer gap-2"
            onClick={() => setViewState('HOME')}
          >
            {settings.logoUrl ? (
               <img src={settings.logoUrl} alt="Logo" className="h-10 w-10 object-contain rounded-lg" />
            ) : (
              <div className="bg-primary p-2 rounded-lg text-white">
                  <ChefHat size={24} />
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-tight tracking-tight text-gray-900 hidden sm:block">
                {settings.restaurantName}
              </span>
              <span className="text-[10px] uppercase tracking-widest text-gray-500 hidden sm:block">
                {settings.tagline}
              </span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-lg relative mx-4">
             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
               <Search size={18} className="text-gray-400" />
             </div>
             <input
               type="text"
               value={searchQuery}
               onChange={(e) => {
                 setSearchQuery(e.target.value);
                 if (e.target.value && currentView !== 'HOME') setViewState('HOME');
               }}
               placeholder="Search..."
               className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-full leading-5 bg-gray-50 text-gray-900 placeholder-gray-500 focus:outline-none focus:bg-white focus:ring-1 focus:ring-primary sm:text-sm transition-colors"
             />
          </div>

          {/* Navigation Links (Desktop) */}
          <div className="hidden md:flex space-x-6 items-center flex-shrink-0">
             <button 
              onClick={() => setViewState('HOME')}
              className={`${currentView === 'HOME' ? 'text-primary font-semibold' : 'text-gray-600 hover:text-primary'} transition-colors`}
            >
              Menu
            </button>
            <button 
              onClick={() => setViewState('TRACK')}
              className={`${currentView === 'TRACK' ? 'text-primary font-semibold' : 'text-gray-600 hover:text-primary'} transition-colors flex items-center gap-1`}
            >
              <Truck size={18} /> <span className="hidden lg:inline">Track Order</span>
            </button>
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-4 flex-shrink-0">
            
            <div className="relative cursor-pointer" onClick={() => setIsCartOpen(true)}>
              <ShoppingBag className="text-gray-700 hover:text-primary transition-colors" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                  {cartCount}
                </span>
              )}
            </div>
            
            {/* Admin/Partner Login Button - Standard Icon */}
            <button 
              onClick={() => setViewState('ADMIN')}
              className="p-2 text-gray-500 hover:text-gray-900 transition-colors"
              title="Partner Login"
            >
              <User size={20} />
            </button>

            <div className="md:hidden">
              <Menu className="text-gray-700" />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;