import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types';
import { Search, Package, Clock, Truck, CheckCircle } from 'lucide-react';

const OrderTracker: React.FC = () => {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    // Auto-load last order if exists
    const lastId = localStorage.getItem('lastOrderId');
    if (lastId) {
      setOrderId(lastId);
      findOrder(lastId);
    }
  }, []);

  const findOrder = (id: string) => {
    const ordersStr = localStorage.getItem('orders');
    if (!ordersStr) {
        setError('No orders found.');
        return;
    }
    const orders: Order[] = JSON.parse(ordersStr);
    const found = orders.find(o => o.id.toUpperCase() === id.toUpperCase());
    
    if (found) {
      setOrder(found);
      setError('');
    } else {
      setOrder(null);
      setError('Order not found. Please check ID.');
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    findOrder(orderId);
  };

  const getStepStatus = (step: OrderStatus, current: OrderStatus) => {
    const steps = [OrderStatus.PENDING, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED];
    const currentIndex = steps.indexOf(current);
    const stepIndex = steps.indexOf(step);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'pending';
  };

  const getEstimatedDeliveryTime = (order: Order) => {
    if (order.status === OrderStatus.DELIVERED) return 'Arrived';
    if (order.status === OrderStatus.CANCELLED) return '-';

    // Deterministic random seed based on order timestamp
    const seed = order.timestamp % 100;

    let min = 0;
    let max = 0;
    let simulatedDelay = 0;

    switch (order.status) {
      case OrderStatus.PENDING:
        min = 45;
        max = 60;
        // Add extra 10-15 minutes for Pending
        simulatedDelay = 10 + (seed % 6);
        break;
      case OrderStatus.PREPARING:
        min = 30;
        max = 45;
        // Add extra 10-15 minutes for Preparing (busy kitchen simulation)
        simulatedDelay = 10 + (seed % 6);
        break;
      case OrderStatus.OUT_FOR_DELIVERY:
        min = 10;
        max = 25;
        // Variable traffic delay (0-20 mins)
        simulatedDelay = (seed % 21);
        break;
      default:
        return 'Calculating...';
    }

    return `${min + simulatedDelay} - ${max + simulatedDelay} mins`;
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-900">Track Your Order</h2>
        <p className="text-gray-500 mt-2">Enter your Order ID to see live status updates</p>
      </div>

      <form onSubmit={handleSearch} className="flex gap-2 max-w-md mx-auto mb-12">
        <input 
          type="text" 
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="e.g. A1B2C3D4"
          className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
        />
        <button type="submit" className="bg-primary text-white px-6 rounded-lg font-bold hover:bg-orange-600 transition-colors">
          <Search size={20} />
        </button>
      </form>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg text-center mb-8 border border-red-100">
          {error}
        </div>
      )}

      {order && (
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          <div className="bg-gray-900 text-white p-6 flex justify-between items-center">
            <div>
              <p className="text-gray-400 text-sm">Order Status</p>
              <h3 className="text-2xl font-bold">{order.status}</h3>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm">Estimated Time</p>
              <p className="font-mono font-bold text-accent">
                {getEstimatedDeliveryTime(order)}
              </p>
            </div>
          </div>

          <div className="p-8">
            {/* Timeline */}
            <div className="relative flex justify-between mb-8">
              {/* Connector Line */}
              <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10 transform -translate-y-1/2 rounded-full"></div>
              
              {[
                { s: OrderStatus.PENDING, icon: Clock, label: "Order Placed" },
                { s: OrderStatus.PREPARING, icon: Package, label: "Preparing" },
                { s: OrderStatus.OUT_FOR_DELIVERY, icon: Truck, label: "Out for Delivery" },
                { s: OrderStatus.DELIVERED, icon: CheckCircle, label: "Delivered" }
              ].map((step, idx) => {
                const status = getStepStatus(step.s, order.status);
                const Icon = step.icon;
                
                return (
                  <div key={idx} className="flex flex-col items-center bg-white px-2">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all duration-500
                      ${status === 'completed' ? 'bg-green-500 border-green-500 text-white' : 
                        status === 'current' ? 'bg-white border-primary text-primary' : 
                        'bg-gray-100 border-gray-200 text-gray-400'}
                    `}>
                      <Icon size={20} />
                    </div>
                    <span className={`mt-2 text-xs font-bold ${status === 'current' ? 'text-primary' : 'text-gray-500'}`}>
                      {step.label}
                    </span>
                  </div>
                )
              })}
            </div>

            <div className="border-t pt-6">
                <h4 className="font-bold mb-4">Order Summary</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                    {order.items.map(item => (
                        <li key={item.id} className="flex justify-between">
                            <span>{item.quantity}x {item.name}</span>
                        </li>
                    ))}
                </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderTracker;