import React, { useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { getAIRecommendation } from '../services/geminiService';
import { MenuItem } from '../types';

interface AIChefProps {
  menuItems: MenuItem[];
}

const AIChef: React.FC<AIChefProps> = ({ menuItems }) => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleAsk = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    const result = await getAIRecommendation(prompt, menuItems);
    setResponse(result);
    setLoading(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-40 bg-gray-900 text-white p-4 rounded-full shadow-xl hover:bg-gray-800 transition-all flex items-center gap-2 animate-bounce"
      >
        <Sparkles size={20} className="text-yellow-400" />
        <span className="font-semibold text-sm">Ask AI Chef</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 left-6 z-40 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 p-4 flex justify-between items-center text-white">
        <div className="flex items-center gap-2">
          <Sparkles size={18} className="text-yellow-400" />
          <h3 className="font-bold text-sm">AI Chef Assistant</h3>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white">&times;</button>
      </div>
      
      <div className="p-4 h-48 overflow-y-auto bg-gray-50 text-sm">
        {!response && !loading && (
          <p className="text-gray-500">Tell me what you're craving! E.g., "Something spicy and filling" or "Healthy vegetarian option".</p>
        )}
        {loading && (
          <div className="flex justify-center items-center h-full text-primary">
            <Loader2 className="animate-spin" />
          </div>
        )}
        {response && (
          <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-100 text-gray-800">
            {response}
          </div>
        )}
      </div>

      <div className="p-3 bg-white border-t flex gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
          placeholder="I'm feeling like..."
          className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
        />
        <button 
          onClick={handleAsk}
          disabled={loading}
          className="bg-primary text-white p-2 rounded-full hover:bg-orange-600 disabled:opacity-50"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  );
};

export default AIChef;