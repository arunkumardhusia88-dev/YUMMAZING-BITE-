import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, MenuItem, AppSettings } from '../types';
import { CURRENCY_SYMBOL } from '../constants';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  UtensilsCrossed, 
  Settings, 
  LogOut, 
  Plus, 
  Edit2, 
  Trash2, 
  Check, 
  X,
  RefreshCw,
  History,
  Save,
  Globe
} from 'lucide-react';

interface AdminPanelProps {
  goBack: () => void;
  onLogout: () => void;
  menuItems: MenuItem[];
  setMenuItems: (items: MenuItem[]) => void;
  settings: AppSettings;
  setSettings: (settings: AppSettings) => void;
}

type AdminTab = 'DASHBOARD' | 'ORDERS' | 'HISTORY' | 'MENU' | 'SETTINGS';

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  goBack, 
  onLogout, 
  menuItems, 
  setMenuItems,
  settings,
  setSettings
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('DASHBOARD');
  const [orders, setOrders] = useState<Order[]>([]);
  const [isEditing, setIsEditing] = useState<number | null>(null); // ID of item being edited
  const [isAdding, setIsAdding] = useState(false);

  // Settings Local State (for form)
  const [tempSettings, setTempSettings] = useState<AppSettings>(settings);

  // Form State for Menu
  const [formData, setFormData] = useState<Partial<MenuItem>>({
    name: '',
    description: '',
    price: 0,
    category: '',
    image: '',
    isVeg: true,
    rating: 4.5
  });

  const loadOrders = () => {
    const stored = localStorage.getItem('orders');
    if (stored) {
      setOrders(JSON.parse(stored));
    }
  };

  useEffect(() => {
    loadOrders();
    const interval = setInterval(loadOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    const updatedOrders = orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    );
    setOrders(updatedOrders);
    localStorage.setItem('orders', JSON.stringify(updatedOrders));
  };

  // --- Menu CRUD Operations ---

  const handleEditClick = (item: MenuItem) => {
    setFormData(item);
    setIsEditing(item.id);
    setIsAdding(false);
  };

  const handleAddClick = () => {
    setFormData({
      name: '',
      description: '',
      price: 0,
      category: 'Mains',
      image: 'https://picsum.photos/400/300',
      isVeg: true,
      rating: 4.5
    });
    setIsAdding(true);
    setIsEditing(null);
  };

  const handleDeleteClick = (id: number) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updatedMenu = menuItems.filter(item => item.id !== id);
      setMenuItems(updatedMenu);
    }
  };

  const handleSaveItem = () => {
    if (!formData.name || !formData.price) {
      alert("Name and Price are required");
      return;
    }

    if (isEditing) {
      // Update existing
      const updatedMenu = menuItems.map(item => 
        item.id === isEditing ? { ...item, ...formData } as MenuItem : item
      );
      setMenuItems(updatedMenu);
      setIsEditing(null);
    } else {
      // Create new
      const newItem: MenuItem = {
        ...formData as MenuItem,
        id: Date.now(), // Simple ID generation
      };
      setMenuItems([...menuItems, newItem]);
      setIsAdding(false);
    }
    // Reset form
    setFormData({});
  };

  // --- Settings Operation ---
  const handleSaveSettings = () => {
    setSettings(tempSettings);
    alert('Settings Saved Successfully!');
  };

  // --- Render Helpers ---

  const renderDashboard = () => {
    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
    const pendingOrders = orders.filter(o => o.status === OrderStatus.PENDING).length;

    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-gray-500 text-sm font-medium">Total Revenue</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{CURRENCY_SYMBOL}{totalRevenue}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-gray-500 text-sm font-medium">Total Orders</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{totalOrders}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-gray-500 text-sm font-medium">Pending Orders</h3>
          <p className="text-3xl font-bold text-orange-600 mt-2">{pendingOrders}</p>
        </div>
      </div>
    );
  };

  const renderMenuEditor = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center bg-gray-50">
        <h2 className="text-lg font-bold text-gray-800">Menu Management</h2>
        <button 
          onClick={handleAddClick}
          className="bg-primary text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-orange-600 transition-colors"
        >
          <Plus size={18} /> Add New Item
        </button>
      </div>

      {(isAdding || isEditing) && (
        <div className="p-6 bg-blue-50 border-b border-blue-100 animate-fadeIn">
          <h3 className="font-bold mb-4 text-blue-800">{isAdding ? 'Add New Item' : 'Edit Item'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Item Name</label>
              <input 
                type="text" 
                value={formData.name} 
                onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full p-2 border rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price</label>
              <input 
                type="number" 
                value={formData.price} 
                onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                className="w-full p-2 border rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select 
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})}
                className="w-full p-2 border rounded-md bg-white"
              >
                <option>Burgers</option>
                <option>Pizza</option>
                <option>Rice</option>
                <option>Mains</option>
                <option>Starters</option>
                <option>Dessert</option>
                <option>Beverages</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
              <input 
                type="text" 
                value={formData.image} 
                onChange={e => setFormData({...formData, image: e.target.value})}
                className="w-full p-2 border rounded-md"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea 
                value={formData.description} 
                onChange={e => setFormData({...formData, description: e.target.value})}
                className="w-full p-2 border rounded-md h-20"
              />
            </div>
            <div className="flex items-center gap-4">
               <label className="flex items-center gap-2 cursor-pointer">
                 <input 
                    type="checkbox" 
                    checked={formData.isVeg} 
                    onChange={e => setFormData({...formData, isVeg: e.target.checked})}
                    className="w-4 h-4 text-primary"
                 />
                 <span className="text-sm font-medium text-gray-700">Vegetarian</span>
               </label>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={handleSaveItem} className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700">
              <Check size={18} /> Save
            </button>
            <button onClick={() => { setIsAdding(false); setIsEditing(null); }} className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-300">
              <X size={18} /> Cancel
            </button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
            <tr>
              <th className="px-6 py-4">Image</th>
              <th className="px-6 py-4">Name</th>
              <th className="px-6 py-4">Category</th>
              <th className="px-6 py-4">Price</th>
              <th className="px-6 py-4">Type</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {menuItems.map(item => (
              <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-3">
                  <img src={item.image} alt={item.name} className="w-10 h-10 rounded object-cover bg-gray-200" />
                </td>
                <td className="px-6 py-3 font-medium text-gray-900">{item.name}</td>
                <td className="px-6 py-3 text-gray-500">{item.category}</td>
                <td className="px-6 py-3 text-gray-900">{CURRENCY_SYMBOL}{item.price}</td>
                <td className="px-6 py-3">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${item.isVeg ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {item.isVeg ? 'VEG' : 'NON-VEG'}
                  </span>
                </td>
                <td className="px-6 py-3 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => handleEditClick(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg" title="Edit">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => handleDeleteClick(item.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderOrders = () => {
    // Filter only active orders
    const activeOrders = orders.filter(order => 
      [OrderStatus.PENDING, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY].includes(order.status)
    );

    return (
      <div className="space-y-6">
         <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">Active Orders</h2>
          <button onClick={loadOrders} className="text-primary hover:bg-orange-50 p-2 rounded-lg flex items-center gap-2">
             <RefreshCw size={20} /> Refresh
          </button>
         </div>
         
         <div className="grid gap-4">
          {activeOrders.length === 0 ? (
             <div className="bg-white p-12 text-center rounded-xl border border-gray-200">
               <ShoppingBag size={48} className="mx-auto text-gray-300 mb-4" />
               <p className="text-gray-500 italic">No active orders right now.</p>
             </div>
          ) : (
            activeOrders.map(order => (
              <div key={order.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col md:flex-row gap-6">
                 <div className="flex-1">
                   <div className="flex items-center gap-3 mb-3">
                     <span className="bg-gray-900 text-white text-xs px-2 py-1 rounded font-mono">#{order.id}</span>
                     <span className="text-sm text-gray-500">{new Date(order.timestamp).toLocaleString()}</span>
                   </div>
                   <h3 className="font-bold text-lg">{order.customerName}</h3>
                   <p className="text-gray-600 text-sm mb-4">{order.address} • {order.customerPhone}</p>
                   <div className="bg-gray-50 p-3 rounded-lg text-sm space-y-1">
                      {order.items.map((item, i) => (
                        <div key={i} className="flex justify-between">
                           <span>{item.quantity}x {item.name}</span>
                           <span className="font-medium">{CURRENCY_SYMBOL}{item.price * item.quantity}</span>
                        </div>
                      ))}
                      <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between font-bold">
                         <span>Total</span>
                         <span>{CURRENCY_SYMBOL}{order.total}</span>
                      </div>
                   </div>
                 </div>
                 
                 <div className="flex flex-col gap-2 min-w-[180px] justify-center border-l border-gray-100 pl-6">
                    <label className="text-xs font-bold text-gray-400 uppercase">Update Status</label>
                    {[OrderStatus.PENDING, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED, OrderStatus.CANCELLED].map(status => (
                      <button
                        key={status}
                        onClick={() => updateOrderStatus(order.id, status)}
                        className={`px-3 py-2 rounded-lg text-sm text-left transition-colors ${order.status === status ? 'bg-gray-900 text-white font-bold' : 'text-gray-600 hover:bg-gray-100'}`}
                      >
                        {status}
                      </button>
                    ))}
                 </div>
              </div>
            ))
          )}
         </div>
      </div>
    );
  };

  const renderHistory = () => {
    // Filter only completed or cancelled orders
    const historyOrders = orders.filter(order => 
      [OrderStatus.DELIVERED, OrderStatus.CANCELLED].includes(order.status)
    );
    // Sort by date desc
    historyOrders.sort((a, b) => b.timestamp - a.timestamp);

    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center bg-gray-50">
          <h2 className="text-lg font-bold text-gray-800">Order History</h2>
          <div className="text-sm text-gray-500">Total: {historyOrders.length}</div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
              <tr>
                <th className="px-6 py-4">Order ID</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4">Items Summary</th>
                <th className="px-6 py-4">Total</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {historyOrders.map(order => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-mono text-xs text-gray-500">#{order.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {new Date(order.timestamp).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">{order.customerName}</div>
                    <div className="text-xs text-gray-500">{order.customerPhone}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">
                    {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                  </td>
                  <td className="px-6 py-4 font-bold text-gray-900">
                    {CURRENCY_SYMBOL}{order.total}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                      order.status === OrderStatus.DELIVERED 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-red-100 text-red-700'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
              {historyOrders.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-500 italic">
                    No history found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderSettings = () => {
    return (
      <div className="max-w-2xl bg-white p-8 rounded-xl shadow-sm border border-gray-200">
        <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Settings size={24} className="text-primary"/> Store Configuration
        </h2>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Restaurant Name</label>
            <input 
              type="text" 
              value={tempSettings.restaurantName}
              onChange={(e) => setTempSettings({...tempSettings, restaurantName: e.target.value})}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tagline / Subtitle</label>
            <input 
              type="text" 
              value={tempSettings.tagline}
              onChange={(e) => setTempSettings({...tempSettings, tagline: e.target.value})}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">WhatsApp Number (with Country Code)</label>
            <input 
              type="text" 
              value={tempSettings.whatsappNumber}
              onChange={(e) => setTempSettings({...tempSettings, whatsappNumber: e.target.value})}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none font-mono"
            />
            <p className="text-xs text-gray-500 mt-1">Example: 919876543210 (No + or spaces)</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Logo URL (Optional)</label>
            <input 
              type="text" 
              value={tempSettings.logoUrl}
              onChange={(e) => setTempSettings({...tempSettings, logoUrl: e.target.value})}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
              placeholder="https://example.com/logo.png"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Hero/Banner Image URL</label>
            <input 
              type="text" 
              value={tempSettings.heroImage}
              onChange={(e) => setTempSettings({...tempSettings, heroImage: e.target.value})}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
            {tempSettings.heroImage && (
              <div className="mt-3 h-32 rounded-lg overflow-hidden relative">
                <img src={tempSettings.heroImage} className="w-full h-full object-cover" alt="Preview"/>
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white text-sm font-bold">Preview</div>
              </div>
            )}
          </div>

          <div className="pt-4 border-t">
            <button 
              onClick={handleSaveSettings}
              className="bg-primary hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-lg flex items-center gap-2 transition-all"
            >
              <Save size={20} /> Save Changes
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-900 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-6 border-b border-gray-800">
           <h1 className="text-xl font-bold tracking-tight">{settings.restaurantName} <span className="text-xs font-normal opacity-50 block">{settings.tagline}</span></h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('DASHBOARD')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'DASHBOARD' ? 'bg-primary text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
          >
            <LayoutDashboard size={20} /> Dashboard
          </button>
          <button 
            onClick={() => setActiveTab('ORDERS')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'ORDERS' ? 'bg-primary text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
          >
            <ShoppingBag size={20} /> Live Orders
          </button>
          <button 
            onClick={() => setActiveTab('HISTORY')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'HISTORY' ? 'bg-primary text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
          >
            <History size={20} /> Order History
          </button>
          <button 
            onClick={() => setActiveTab('MENU')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'MENU' ? 'bg-primary text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
          >
            <UtensilsCrossed size={20} /> Menu Manager
          </button>
          <button 
            onClick={() => setActiveTab('SETTINGS')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'SETTINGS' ? 'bg-primary text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
          >
            <Settings size={20} /> Settings
          </button>
        </nav>

        <div className="p-4 border-t border-gray-800">
          <button 
            onClick={goBack}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors mb-2"
          >
            <Globe size={20} /> Visit Customer Site
          </button>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-900/20 transition-colors"
          >
            <LogOut size={20} /> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto h-screen">
        <header className="bg-white shadow-sm sticky top-0 z-30 px-8 py-4 flex justify-between items-center md:hidden">
           <span className="font-bold text-gray-900">Admin Portal</span>
           <button onClick={onLogout} className="p-2 text-red-600"><LogOut size={20}/></button>
        </header>

        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">
              {activeTab === 'DASHBOARD' && 'Dashboard'}
              {activeTab === 'ORDERS' && 'Live Order Management'}
              {activeTab === 'HISTORY' && 'Order History'}
              {activeTab === 'MENU' && 'Menu Editor'}
              {activeTab === 'SETTINGS' && 'Store Settings'}
            </h1>
          </div>

          {activeTab === 'DASHBOARD' && renderDashboard()}
          {activeTab === 'ORDERS' && renderOrders()}
          {activeTab === 'HISTORY' && renderHistory()}
          {activeTab === 'MENU' && renderMenuEditor()}
          {activeTab === 'SETTINGS' && renderSettings()}
        </div>
      </main>
    </div>
  );
};

export default AdminPanel;