import React, { useState } from 'react';
import { Lock, User, ChefHat, ArrowLeft } from 'lucide-react';
import { AppSettings } from '../types';

interface LoginProps {
  onLogin: () => void;
  onCancel: () => void;
  settings: AppSettings;
}

const Login: React.FC<LoginProps> = ({ onLogin, onCancel, settings }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // STRICT ADMIN CREDENTIALS
    // Only these credentials will allow access to the backend dashboard
    if (username.toLowerCase() === 'admin' && password === 'admin') {
      onLogin();
    } else {
      // Generic error message for security (don't reveal the password)
      setError('Invalid username or password. Access denied.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-gray-900 p-8 text-center relative">
          <button 
            onClick={onCancel}
            className="absolute top-4 left-4 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="mx-auto bg-primary w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-lg text-white">
            <ChefHat size={32} />
          </div>
          <h2 className="text-2xl font-bold text-white">Partner Login</h2>
          <p className="text-gray-400 text-sm mt-1">{settings.restaurantName}</p>
        </div>

        {/* Form */}
        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg border border-red-100 text-center animate-pulse">
                {error}
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User size={18} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary sm:text-sm transition-all"
                  placeholder="Enter ID"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock size={18} className="text-gray-400" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary sm:text-sm transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-white bg-primary hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all transform active:scale-95"
            >
              Login to Dashboard
            </button>
          </form>

          <div className="mt-6 text-center">
             <p className="text-xs text-gray-400">Authorized personnel only.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;