// In a real app, this would be the restaurant's WhatsApp number
// Format: CountryCode + Number (e.g., 919876543210)
export const WHATSAPP_NUMBER = "919876543210"; 

export const CURRENCY_SYMBOL = "₹";
