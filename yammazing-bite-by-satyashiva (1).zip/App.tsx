import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import CartSheet from './components/CartSheet';
import AdminPanel from './components/AdminPanel';
import OrderTracker from './components/OrderTracker';
import AIChef from './components/AIChef';
import Login from './components/Login';
import { MENU_ITEMS } from './services/mockData';
import { CartItem, ViewState, MenuItem, AppSettings } from './types';
import { Plus, Star } from 'lucide-react';
import { CURRENCY_SYMBOL } from './constants';

const DEFAULT_SETTINGS: AppSettings = {
  restaurantName: "Yammazing Bite",
  tagline: "by Satyashiva",
  heroImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=2070",
  whatsappNumber: "919876543210",
  logoUrl: "" // Empty defaults to Icon
};

const App: React.FC = () => {
  const [viewState, setViewState] = useState<ViewState>('HOME');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Auth State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // App Data State
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  // Load Settings
  useEffect(() => {
    const storedSettings = localStorage.getItem('appSettings');
    if (storedSettings) {
      setSettings(JSON.parse(storedSettings));
    }
  }, []);

  // Save Settings
  useEffect(() => {
    localStorage.setItem('appSettings', JSON.stringify(settings));
  }, [settings]);

  // Load Menu
  useEffect(() => {
    const storedMenu = localStorage.getItem('menuItems');
    if (storedMenu) {
      setMenuItems(JSON.parse(storedMenu));
    } else {
      setMenuItems(MENU_ITEMS);
    }
  }, []);

  // Save Menu
  useEffect(() => {
    if (menuItems.length > 0) {
      localStorage.setItem('menuItems', JSON.stringify(menuItems));
    }
  }, [menuItems]);

  // Load cart
  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  // Save cart
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (item: MenuItem) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: number, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const removeFromCart = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const clearCart = () => setCartItems([]);

  // --- SEPARATE BACKEND APP LOGIC ---
  if (viewState === 'ADMIN') {
    if (!isAdminLoggedIn) {
      return (
        <Login 
          onLogin={() => setIsAdminLoggedIn(true)} 
          onCancel={() => setViewState('HOME')}
          settings={settings}
        />
      );
    }
    return (
      <AdminPanel 
        goBack={() => setViewState('HOME')} 
        onLogout={() => { setIsAdminLoggedIn(false); setViewState('HOME'); }}
        menuItems={menuItems}
        setMenuItems={setMenuItems}
        settings={settings}
        setSettings={setSettings}
      />
    );
  }

  // --- CUSTOMER APP LOGIC ---

  const categories = ['All', ...Array.from(new Set(menuItems.map(item => item.category)))];
  
  const filteredItems = menuItems.filter(item => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen pb-20 bg-gray-50">
      <Navbar 
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)} 
        setIsCartOpen={setIsCartOpen}
        setViewState={setViewState}
        currentView={viewState}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        settings={settings}
      />

      <CartSheet 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
        clearCart={clearCart}
        whatsappNumber={settings.whatsappNumber}
      />

      {/* Main Content Router */}
      <main className="pt-6">
        {viewState === 'HOME' && (
          <>
            {/* Hero Section */}
            {!searchQuery && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
                <div className="relative rounded-3xl overflow-hidden bg-gray-900 h-64 md:h-96 flex items-center shadow-2xl">
                  <img 
                    src={settings.heroImage}
                    alt="Food Hero" 
                    className="absolute inset-0 w-full h-full object-cover opacity-50"
                  />
                  <div className="relative z-10 px-8 md:px-16 max-w-2xl">
                    <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-4 leading-tight">
                      {settings.restaurantName} <br/><span className="text-primary">Delicious & Fresh</span>
                    </h1>
                    <p className="text-gray-200 text-lg mb-8">
                      {settings.tagline || "Authentic flavors directly to your doorstep. Hot, fresh, and hygienic."}
                    </p>
                    <button 
                      onClick={() => {
                          document.getElementById('menu-section')?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="bg-primary hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-full transition-all transform hover:scale-105 shadow-lg"
                    >
                      Order Now
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Menu Section */}
            <div id="menu-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              
              <div className="flex flex-wrap gap-3 mb-8 justify-center md:justify-start">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-5 py-2 rounded-full text-sm font-semibold transition-all ${
                      selectedCategory === cat 
                        ? 'bg-gray-900 text-white shadow-md' 
                        : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {filteredItems.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-xl text-gray-500">No items found matching "{searchQuery}"</p>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="mt-4 text-primary font-semibold hover:underline"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {filteredItems.map(item => (
                    <div key={item.id} className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-shadow duration-300 overflow-hidden group border border-gray-100 flex flex-col">
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-bold flex items-center gap-1 shadow-sm">
                          <Star size={12} className="text-yellow-500 fill-yellow-500" /> {item.rating}
                        </div>
                        {item.isVeg ? (
                           <div className="absolute top-3 right-3 bg-green-500 p-1.5 rounded-sm border-2 border-white shadow-sm" title="Veg">
                              <div className="w-2 h-2 bg-white rounded-full"></div>
                           </div>
                        ) : (
                           <div className="absolute top-3 right-3 bg-red-500 p-1.5 rounded-sm border-2 border-white shadow-sm" title="Non-Veg">
                               <div className="w-2 h-2 bg-white rounded-full"></div>
                           </div>
                        )}
                      </div>
                      
                      <div className="p-5 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-bold text-gray-900 leading-tight">{item.name}</h3>
                          <span className="text-lg font-bold text-primary">{CURRENCY_SYMBOL}{item.price}</span>
                        </div>
                        <p className="text-gray-500 text-sm mb-4 line-clamp-2">{item.description}</p>
                        
                        <div className="mt-auto">
                          <button 
                            onClick={() => addToCart(item)}
                            className="w-full bg-gray-900 hover:bg-primary text-white font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2"
                          >
                            <Plus size={18} /> Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <AIChef menuItems={menuItems} />
          </>
        )}

        {viewState === 'TRACK' && <OrderTracker />}
      </main>

      <footer className="mt-20 bg-gray-900 text-gray-400 py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="mb-4 text-2xl font-bold text-white">{settings.restaurantName}</p>
          <p className="mb-6 text-gray-500">{settings.tagline}</p>
          <p>© 2024 {settings.restaurantName}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;