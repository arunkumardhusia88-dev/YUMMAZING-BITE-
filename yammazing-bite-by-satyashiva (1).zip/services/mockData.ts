import { MenuItem } from '../types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 1,
    name: "Truffle Mushroom Burger",
    description: "Brioche bun, wild mushrooms, truffle oil, swiss cheese.",
    price: 349,
    category: "Burgers",
    image: "https://picsum.photos/400/300?random=1",
    isVeg: true,
    rating: 4.8
  },
  {
    id: 2,
    name: "Spicy Peri-Peri Chicken",
    description: "Grilled chicken breast, spicy peri-peri sauce, coleslaw.",
    price: 399,
    category: "Mains",
    image: "https://picsum.photos/400/300?random=2",
    isVeg: false,
    rating: 4.5
  },
  {
    id: 3,
    name: "Margherita Basilico",
    description: "Fresh mozzarella, san marzano tomato sauce, fresh basil.",
    price: 299,
    category: "Pizza",
    image: "https://picsum.photos/400/300?random=3",
    isVeg: true,
    rating: 4.6
  },
  {
    id: 4,
    name: "Chicken Tikka Bowl",
    description: "Saffron rice, smoky chicken tikka, makhani gravy.",
    price: 329,
    category: "Bowls",
    image: "https://picsum.photos/400/300?random=4",
    isVeg: false,
    rating: 4.9
  },
  {
    id: 5,
    name: "Paneer Butter Masala",
    description: "Cottage cheese cubes in rich tomato cashew gravy.",
    price: 289,
    category: "Mains",
    image: "https://picsum.photos/400/300?random=5",
    isVeg: true,
    rating: 4.7
  },
  {
    id: 6,
    name: "Double Chocolate Brownie",
    description: "Gooey chocolate brownie topped with walnut.",
    price: 149,
    category: "Dessert",
    image: "https://picsum.photos/400/300?random=6",
    isVeg: false,
    rating: 4.9
  },
    {
    id: 7,
    name: "Crispy Corn & Spinach",
    description: "Golden fried corn kernels with spinach and spices.",
    price: 199,
    category: "Starters",
    image: "https://picsum.photos/400/300?random=7",
    isVeg: true,
    rating: 4.4
  },
  {
    id: 8,
    name: "Hydrabadi Chicken Biryani",
    description: "Aromatic basmati rice cooked with spicy chicken and herbs.",
    price: 359,
    category: "Rice",
    image: "https://picsum.photos/400/300?random=8",
    isVeg: false,
    rating: 4.9
  }
];
