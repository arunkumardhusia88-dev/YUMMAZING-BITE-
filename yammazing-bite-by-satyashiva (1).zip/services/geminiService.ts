import { GoogleGenAI } from "@google/genai";
import { MenuItem } from "../types";

// Initialize Gemini
// Note: In a real production app, use a proxy backend to hide the API key.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIRecommendation = async (userMood: string, currentMenu: MenuItem[]): Promise<string> => {
  if (!process.env.API_KEY) {
    return "Please configure your API Key to use the AI Chef feature.";
  }

  // Use the dynamic menu passed from the component
  const menuString = currentMenu.map(item => `${item.name} (${item.isVeg ? 'Veg' : 'Non-Veg'}) - ${item.description}`).join('\n');

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `
        You are a smart waiter/chef at a modern cloud kitchen.
        The user says: "${userMood}".
        
        Here is our current menu:
        ${menuString}
        
        Recommend 1 or 2 specific dishes from the menu that match their request.
        Keep the tone fun, appetizing, and short (max 50 words).
        Do not make up items that are not on the menu.
      `,
    });

    return response.text || "I recommend trying our Chef's Special!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting to the kitchen brain right now. But everything on the menu is delicious!";
  }
};